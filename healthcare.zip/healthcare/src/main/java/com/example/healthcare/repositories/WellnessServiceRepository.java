package com.example.healthcare.repositories;

import com.example.healthcare.entities.WellnessService;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WellnessServiceRepository extends JpaRepository<WellnessService, Long> {}
