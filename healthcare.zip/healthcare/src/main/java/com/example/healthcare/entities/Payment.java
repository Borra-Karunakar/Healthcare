// src/main/java/com/example/healthcare/entities/Payment.java
package com.example.healthcare.entities;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "payments")
public class Payment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional=false) @JoinColumn(name="patient_id")
    private Patient patient;

    @OneToOne @JoinColumn(name="appointment_id", unique = true)
    private Appointment appointment; // nullable if paying for service

    @ManyToOne @JoinColumn(name="service_id")
    private WellnessService service;  // nullable if paying for appointment

    @Enumerated(EnumType.STRING)
    @Column(nullable=false)
    private PaymentStatus paymentStatus = PaymentStatus.PENDING;

    @Column(nullable=false)
    private LocalDateTime paymentDate = LocalDateTime.now();

    private String transactionId;

    // getters/setters...
    public Long getId() { return id; }
    public Patient getPatient() { return patient; }
    public Appointment getAppointment() { return appointment; }
    public WellnessService getService() { return service; }
    public PaymentStatus getPaymentStatus() { return paymentStatus; }
    public LocalDateTime getPaymentDate() { return paymentDate; }
    public String getTransactionId() { return transactionId; }
    public void setId(Long id) { this.id = id; }
    public void setPatient(Patient patient) { this.patient = patient; }
    public void setAppointment(Appointment appointment) { this.appointment = appointment; }
    public void setService(WellnessService service) { this.service = service; }
    public void setPaymentStatus(PaymentStatus paymentStatus) { this.paymentStatus = paymentStatus; }
    public void setPaymentDate(LocalDateTime paymentDate) { this.paymentDate = paymentDate; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }
}
