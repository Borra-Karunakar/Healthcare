package com.example.healthcare.dto;

import com.example.healthcare.entities.AppointmentStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AppointmentDTO {
    private Long id;
    private LocalDateTime date;
    private AppointmentStatus status;
    private Long patientId;
    private Long providerId;
}
