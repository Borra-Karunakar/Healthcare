package com.example.healthcare;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.security.crypto.password.PasswordEncoder; // ✅ import

import com.example.healthcare.entities.*;
import com.example.healthcare.repositories.*;

@Component
public class DataLoader implements CommandLineRunner {

    private final WellnessServiceRepository serviceRepo;
    private final ProviderRepository providerRepo;
    private final PatientRepository patientRepo;
    private final PasswordEncoder passwordEncoder; // ✅ add encoder

    public DataLoader(WellnessServiceRepository s,
                      ProviderRepository p,
                      PatientRepository pr,
                      PasswordEncoder pe) {
        this.serviceRepo = s;
        this.providerRepo = p;
        this.patientRepo = pr;
        this.passwordEncoder = pe; // ✅ assign encoder
    }

    @Override
    public void run(String... args) {
        // ✅ Add demo services only if none exist
        if (serviceRepo.count() == 0) {
            serviceRepo.save(new WellnessService("Yoga Session", "1-hour guided yoga class", 60, 500.0));
            serviceRepo.save(new WellnessService("Diet Consultation", "Personalized diet plan", 30, 300.0));
        }

        // ✅ Add demo providers only if not already in DB
        if (providerRepo.findByEmail("rahul.verma@example.com").isEmpty()) {
            Provider doctor1 = new Provider();
            doctor1.setName("Dr. Rahul Verma");
            doctor1.setEmail("rahul.verma@example.com");
            doctor1.setPassword(passwordEncoder.encode("pass123")); // ✅ encode password
            doctor1.setSpecialization("Cardiologist");
            doctor1.setPhone("9876543210");
            doctor1.setRole(UserRole.PROVIDER);
            providerRepo.save(doctor1);
        }

        if (providerRepo.findByEmail("sneha.kapoor@example.com").isEmpty()) {
            Provider doctor2 = new Provider();
            doctor2.setName("Dr. Sneha Kapoor");
            doctor2.setEmail("sneha.kapoor@example.com");
            doctor2.setPassword(passwordEncoder.encode("pass123")); // ✅ encode password
            doctor2.setSpecialization("Dermatologist");
            doctor2.setPhone("9876501234");
            doctor2.setRole(UserRole.PROVIDER);
            providerRepo.save(doctor2);
        }

        // ✅ Add demo patients only if not already in DB
        if (patientRepo.findByEmail("arjun.mehta@example.com").isEmpty()) {
            Patient patient1 = new Patient();
            patient1.setName("Arjun Mehta");
            patient1.setEmail("arjun.mehta@example.com");
            patient1.setPassword(passwordEncoder.encode("pass123")); // ✅ encode password
            patient1.setPhone("9123456780");
            patient1.setRole(UserRole.PATIENT);
            patientRepo.save(patient1);
        }

        if (patientRepo.findByEmail("priya.sharma@example.com").isEmpty()) {
            Patient patient2 = new Patient();
            patient2.setName("Priya Sharma");
            patient2.setEmail("priya.sharma@example.com");
            patient2.setPassword(passwordEncoder.encode("pass123")); // ✅ encode password
            patient2.setPhone("9988776655");
            patient2.setRole(UserRole.PATIENT);
            patientRepo.save(patient2);
        }
    }
}
