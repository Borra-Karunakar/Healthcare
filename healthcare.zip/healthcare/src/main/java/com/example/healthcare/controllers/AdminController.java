// src/main/java/com/example/healthcare/controllers/AdminController.java
package com.example.healthcare.controllers;

import com.example.healthcare.entities.*;
import com.example.healthcare.repositories.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:3000") // allow frontend
public class AdminController {

    private final PatientRepository patientRepo;
    private final ProviderRepository providerRepo;
    private final AppointmentRepository appointmentRepo;
    private final WellnessServiceRepository serviceRepo;

    public AdminController(PatientRepository patientRepo,
                           ProviderRepository providerRepo,
                           AppointmentRepository appointmentRepo,
                           WellnessServiceRepository serviceRepo) {
        this.patientRepo = patientRepo;
        this.providerRepo = providerRepo;
        this.appointmentRepo = appointmentRepo;
        this.serviceRepo = serviceRepo;
    }

    // ---------------- PATIENTS ----------------
    @GetMapping("/patients")
    public List<Patient> getAllPatients() {
        return patientRepo.findAll();
    }

    @DeleteMapping("/patients/{id}")
    public ResponseEntity<?> deletePatient(@PathVariable Long id) {
        return patientRepo.findById(id)
                .map(p -> {
                    patientRepo.delete(p);
                    return ResponseEntity.ok("Patient deleted successfully");
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // ---------------- PROVIDERS ----------------
    @GetMapping("/providers")
    public List<Provider> getAllProviders() {
        return providerRepo.findAll();
    }

    @DeleteMapping("/providers/{id}")
    public ResponseEntity<?> deleteProvider(@PathVariable Long id) {
        return providerRepo.findById(id)
                .map(p -> {
                    providerRepo.delete(p);
                    return ResponseEntity.ok("Provider deleted successfully");
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // ---------------- APPOINTMENTS ----------------
    @GetMapping("/appointments")
    public List<Appointment> getAllAppointments() {
        return appointmentRepo.findAll();
    }

    // ---------------- WELLNESS SERVICES ----------------
    @GetMapping("/services")
    public List<WellnessService> getAllServices() {
        return serviceRepo.findAll();
    }

    @PostMapping("/services")
    public ResponseEntity<WellnessService> createService(@RequestBody WellnessService service) {
        return ResponseEntity.ok(serviceRepo.save(service));
    }

    @PutMapping("/services/{id}")
    public ResponseEntity<?> updateService(@PathVariable Long id, @RequestBody WellnessService updated) {
        return serviceRepo.findById(id)
                .map(s -> {
                    s.setName(updated.getName());
                    s.setDescription(updated.getDescription());
                    s.setDuration(updated.getDuration());
                    s.setFee(updated.getFee());
                    serviceRepo.save(s);
                    return ResponseEntity.ok("Service updated successfully");
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/services/{id}")
    public ResponseEntity<?> deleteService(@PathVariable Long id) {
        return serviceRepo.findById(id)
                .map(s -> {
                    serviceRepo.delete(s);
                    return ResponseEntity.ok("Service deleted successfully");
                })
                .orElse(ResponseEntity.notFound().build());
    }
}
