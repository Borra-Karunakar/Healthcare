package com.example.healthcare.services;

import com.example.healthcare.entities.Appointment;
import com.example.healthcare.repositories.AppointmentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppointmentService {
    private final AppointmentRepository repo;

    public AppointmentService(AppointmentRepository repo) {
        this.repo = repo;
    }

    public List<Appointment> getAllAppointments() {
        return repo.findAll();
    }

    public Appointment getAppointmentById(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Appointment not found with id: " + id));
    }

    public Appointment createAppointment(Appointment appointment) {
        return repo.save(appointment);
    }

    public Appointment updateAppointment(Long id, Appointment appointmentDetails) {
        Appointment appointment = getAppointmentById(id);
        appointment.setDate(appointmentDetails.getDate());
        appointment.setStatus(appointmentDetails.getStatus());
        return repo.save(appointment);
    }

    public void deleteAppointment(Long id) {
        repo.deleteById(id);
    }
}
