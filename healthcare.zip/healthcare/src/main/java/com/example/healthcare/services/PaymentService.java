package com.example.healthcare.services;

import com.example.healthcare.entities.Payment;
import com.example.healthcare.repositories.PaymentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PaymentService {
    private final PaymentRepository repo;

    public PaymentService(PaymentRepository repo) {
        this.repo = repo;
    }

    public List<Payment> getAllPayments() {
        return repo.findAll();
    }

    public Payment getPaymentById(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment not found with id: " + id));
    }

    public Payment createPayment(Payment payment) {
        return repo.save(payment);
    }
}
