package com.example.healthcare.entities;

public enum Role {
    PATIENT,
    PROVIDER,
    ADMIN
}

