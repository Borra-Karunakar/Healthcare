package com.example.healthcare.services;

import com.example.healthcare.entities.Provider;
import com.example.healthcare.repositories.ProviderRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProviderService {
    private final ProviderRepository repo;

    public ProviderService(ProviderRepository repo) {
        this.repo = repo;
    }

    public List<Provider> getAllProviders() {
        return repo.findAll();
    }

    public Provider getProviderById(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Provider not found with id: " + id));
    }

    public Provider createProvider(Provider provider) {
        return repo.save(provider);
    }

    public Provider updateProvider(Long id, Provider providerDetails) {
        Provider provider = getProviderById(id);
        provider.setName(providerDetails.getName());
        provider.setEmail(providerDetails.getEmail());
        provider.setPhone(providerDetails.getPhone());
        provider.setSpecialization(providerDetails.getSpecialization());
        return repo.save(provider);
    }

    public void deleteProvider(Long id) {
        repo.deleteById(id);
    }
}
