package com.example.healthcare.services;

import com.example.healthcare.dto.PatientDTO;
import com.example.healthcare.entities.Patient;
import com.example.healthcare.exceptions.ResourceNotFoundException;
import com.example.healthcare.repositories.PatientRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PatientService {

    private final PatientRepository patientRepo;

    public PatientService(PatientRepository patientRepo) {
        this.patientRepo = patientRepo;
    }

    // ✅ Convert Entity → DTO
    private PatientDTO mapToDTO(Patient patient) {
        return new PatientDTO(
                patient.getId(),
                patient.getName(),
                patient.getEmail(),
                patient.getPhone()
        );
    }

    // ✅ Convert DTO → Entity
    private Patient mapToEntity(PatientDTO dto) {
        Patient p = new Patient();
        p.setId(dto.getId());
        p.setName(dto.getName());
        p.setEmail(dto.getEmail());
        p.setPhone(dto.getPhone());
        return p;
    }

    public List<PatientDTO> getAllPatients() {
        return patientRepo.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public PatientDTO getPatientById(Long id) {
        Patient patient = patientRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with ID: " + id));
        return mapToDTO(patient);
    }

    // ✅ Create with duplicate email check
    public PatientDTO createPatient(Patient patient) {
        if (patientRepo.findByEmail(patient.getEmail()).isPresent()) {
            throw new IllegalArgumentException("Email already registered!");
        }
        return mapToDTO(patientRepo.save(patient));
    }

    public PatientDTO updatePatient(Long id, Patient updatedPatient) {
        Patient patient = patientRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with ID: " + id));

        patient.setName(updatedPatient.getName());
        patient.setEmail(updatedPatient.getEmail());
        patient.setPhone(updatedPatient.getPhone());
        patient.setPassword(updatedPatient.getPassword()); // keep hashed in real app

        return mapToDTO(patientRepo.save(patient));
    }

    public void deletePatient(Long id) {
        Patient patient = patientRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with ID: " + id));
        patientRepo.delete(patient);
    }
}
