// File: AuthController.java
package com.example.healthcare.auth;

import com.example.healthcare.entities.Patient;
import com.example.healthcare.entities.Provider;
import com.example.healthcare.entities.Admin;
import com.example.healthcare.entities.UserRole;
import com.example.healthcare.repositories.PatientRepository;
import com.example.healthcare.repositories.ProviderRepository;
import com.example.healthcare.repositories.AdminRepository;
import com.example.healthcare.security.JwtUtil;

import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3000") // Allow React frontend
public class AuthController {

    private final PatientRepository patientRepo;
    private final ProviderRepository providerRepo;
    private final AdminRepository adminRepo;
    private final PasswordEncoder encoder;
    private final JwtUtil jwt;

    public AuthController(PatientRepository pr, ProviderRepository pvr,
                          AdminRepository ar, PasswordEncoder e, JwtUtil j) {
        this.patientRepo = pr;
        this.providerRepo = pvr;
        this.adminRepo = ar;
        this.encoder = e;
        this.jwt = j;
    }

    // ---------------- REGISTER ----------------
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest req) {
        String role = req.getRole() == null ? "PATIENT" : req.getRole().toUpperCase();

        if ("PROVIDER".equals(role)) {
            Provider p = new Provider();
            p.setName(req.getName());
            p.setEmail(req.getEmail());
            p.setPassword(encoder.encode(req.getPassword()));
            p.setSpecialization(req.getSpecialization());
            p.setRole(UserRole.PROVIDER);

            providerRepo.save(p);
            String token = jwt.generateToken(p.getEmail(), p.getRole().name());

            return ResponseEntity.ok(new JwtResponse(token, p.getRole().name()));

        } else if ("ADMIN".equals(role)) {
            Admin a = new Admin();
            a.setName(req.getName());
            a.setEmail(req.getEmail());
            a.setPassword(encoder.encode(req.getPassword()));
            a.setPhone(req.getPhone());
            a.setRole(UserRole.ADMIN);

            adminRepo.save(a);
            String token = jwt.generateToken(a.getEmail(), a.getRole().name());

            return ResponseEntity.ok(new JwtResponse(token, a.getRole().name()));

        } else { // default: PATIENT
            Patient p = new Patient();
            p.setName(req.getName());
            p.setEmail(req.getEmail());
            p.setPassword(encoder.encode(req.getPassword()));
            p.setPhone(req.getPhone());
            p.setRole(UserRole.PATIENT);

            patientRepo.save(p);
            String token = jwt.generateToken(p.getEmail(), p.getRole().name());

            return ResponseEntity.ok(new JwtResponse(token, p.getRole().name()));
        }
    }

    // ---------------- LOGIN ----------------
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
        // Check Patient
        Optional<Patient> patient = patientRepo.findByEmail(req.getEmail());
        if (patient.isPresent() && encoder.matches(req.getPassword(), patient.get().getPassword())) {
            String token = jwt.generateToken(req.getEmail(), patient.get().getRole().name());
            return ResponseEntity.ok(new JwtResponse(token, patient.get().getRole().name()));
        }

        // Check Provider
        Optional<Provider> provider = providerRepo.findByEmail(req.getEmail());
        if (provider.isPresent() && encoder.matches(req.getPassword(), provider.get().getPassword())) {
            String token = jwt.generateToken(req.getEmail(), provider.get().getRole().name());
            return ResponseEntity.ok(new JwtResponse(token, provider.get().getRole().name()));
        }

        // Check Admin
        Optional<Admin> admin = adminRepo.findByEmail(req.getEmail());
        if (admin.isPresent() && encoder.matches(req.getPassword(), admin.get().getPassword())) {
            String token = jwt.generateToken(req.getEmail(), admin.get().getRole().name());
            return ResponseEntity.ok(new JwtResponse(token, admin.get().getRole().name()));
        }

        return ResponseEntity.status(401).body("Invalid email or password");
    }
}
