// src/main/java/com/example/healthcare/controllers/WellnessServiceController.java
package com.example.healthcare.controllers;

import com.example.healthcare.entities.WellnessService;
import com.example.healthcare.repositories.WellnessServiceRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/services")
public class WellnessServiceController {

    private final WellnessServiceRepository repo;

    public WellnessServiceController(WellnessServiceRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<WellnessService> getAll() {
        return repo.findAll();
    }

    @PostMapping
    public ResponseEntity<WellnessService> create(@RequestBody WellnessService s) {
        // (Optionally) restrict to ADMIN in SecurityConfig
        return ResponseEntity.ok(repo.save(s));
    }
}
