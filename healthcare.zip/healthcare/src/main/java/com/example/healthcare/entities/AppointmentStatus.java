// src/main/java/com/example/healthcare/entities/AppointmentStatus.java
package com.example.healthcare.entities;

public enum AppointmentStatus {
    PENDING,
    CONFIRMED,
    CANCELLED,
    COMPLETED   // 👈 Add this if missing
}
