// src/main/java/com/example/healthcare/controllers/ProviderController.java
package com.example.healthcare.controllers;

import com.example.healthcare.entities.Provider;
import com.example.healthcare.repositories.ProviderRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/providers")
public class ProviderController {

    private final ProviderRepository repo;

    public ProviderController(ProviderRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Provider> all() {
        return repo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Provider> getOne(@PathVariable Long id) {
        return repo.findById(id).map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Provider> update(@PathVariable Long id, @RequestBody Provider incoming) {
        return repo.findById(id).map(p -> {
            if (incoming.getName() != null) p.setName(incoming.getName());
            if (incoming.getPhone() != null) p.setPhone(incoming.getPhone());
            if (incoming.getEmail() != null) p.setEmail(incoming.getEmail());
            if (incoming.getSpecialization() != null) p.setSpecialization(incoming.getSpecialization());
            return ResponseEntity.ok(repo.save(p));
        }).orElse(ResponseEntity.notFound().build());
    }
}
