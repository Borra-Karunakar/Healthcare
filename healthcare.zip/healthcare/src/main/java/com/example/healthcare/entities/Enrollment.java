// src/main/java/com/example/healthcare/entities/Enrollment.java
package com.example.healthcare.entities;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "enrollments")
public class Enrollment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional=false) @JoinColumn(name="patient_id")
    private Patient patient;

    @ManyToOne(optional=false) @JoinColumn(name="service_id")
    private WellnessService service;

    @Column(nullable=false)
    private LocalDate startDate;

    @Column(nullable=false)
    private LocalDate endDate;

    @Column(nullable=false)
    private Integer progress = 0; // 0–100

    // getters/setters
    public Long getId() { return id; }
    public Patient getPatient() { return patient; }
    public WellnessService getService() { return service; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public Integer getProgress() { return progress; }
    public void setId(Long id) { this.id = id; }
    public void setPatient(Patient patient) { this.patient = patient; }
    public void setService(WellnessService service) { this.service = service; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
    public void setProgress(Integer progress) { this.progress = progress; }
}
