package com.example.healthcare.entities;

public enum EnrollmentStatus {
    ACTIVE,
    CANCELLED,
    COMPLETED
}
