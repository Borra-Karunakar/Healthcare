// src/main/java/com/example/healthcare/controllers/EnrollmentController.java
package com.example.healthcare.controllers;

import com.example.healthcare.dto.EnrollmentDTO;
import com.example.healthcare.services.EnrollmentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/enrollments")
@CrossOrigin(origins = "http://localhost:3000")
public class EnrollmentController {
    private final EnrollmentService service;
    public EnrollmentController(EnrollmentService s){ this.service = s; }

    @PostMapping
    public ResponseEntity<EnrollmentDTO> create(@RequestBody EnrollmentDTO dto){
        return ResponseEntity.ok(service.create(dto));
    }

    @GetMapping
    public ResponseEntity<List<EnrollmentDTO>> all(){
        return ResponseEntity.ok(service.all());
    }

    @GetMapping("/patient/{patientId}")
    public ResponseEntity<List<EnrollmentDTO>> byPatient(@PathVariable Long patientId){
        return ResponseEntity.ok(service.byPatient(patientId));
    }

    @PatchMapping("/{id}/progress/{value}")
    public ResponseEntity<EnrollmentDTO> progress(@PathVariable Long id, @PathVariable Integer value){
        return ResponseEntity.ok(service.updateProgress(id, value));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
