// src/main/java/com/example/healthcare/BootstrapData.java
package com.example.healthcare;

import com.example.healthcare.entities.*;
import com.example.healthcare.repositories.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class BootstrapData {
    @Bean
    CommandLineRunner initData(
            AdminRepository adminRepo,
            WellnessServiceRepository serviceRepo,
            ProviderRepository providerRepo,
            PasswordEncoder encoder
    ){
        return args -> {
            if (adminRepo.count() == 0) {
                Admin a = new Admin();
                a.setName("System Admin");
                a.setEmail("admin@example.com");
                a.setPassword(encoder.encode("Admin@123")); // or keep the same password
                a.setPhone("1234567890");
                a.setRole(UserRole.ADMIN);
                
                adminRepo.save(a);
            }
            if (serviceRepo.count() == 0) {
                WellnessService s = new WellnessService();
                s.setName("Yoga Basics");
                s.setDescription("Beginner friendly yoga sessions");
                s.setDuration(30);
                s.setFee(999.00);
                serviceRepo.save(s);
            }
            if (providerRepo.count() == 0) {
                Provider p = new Provider();
                p.setName("Dr. Sneha Kapoor");
                p.setEmail("sneha.kapoor@example.com");
                p.setPassword(encoder.encode("Provider@123"));
                p.setRole(UserRole.PROVIDER);
                p.setSpecialization("Physician");
                providerRepo.save(p);
            }
        };
    }
}
