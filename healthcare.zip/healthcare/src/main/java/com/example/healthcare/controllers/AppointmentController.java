package com.example.healthcare.controllers;

import com.example.healthcare.entities.*;
import com.example.healthcare.repositories.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/appointments")
@CrossOrigin(origins = "http://localhost:3000") // allow frontend
public class AppointmentController {

    private final AppointmentRepository repo;
    private final PatientRepository patientRepo;
    private final ProviderRepository providerRepo;

    public AppointmentController(AppointmentRepository repo,
                                 PatientRepository patientRepo,
                                 ProviderRepository providerRepo) {
        this.repo = repo;
        this.patientRepo = patientRepo;
        this.providerRepo = providerRepo;
    }

    // ------------------- DTOs -------------------
    public record CreateAppointmentRequest(Long patientId,
                                           Long providerId,
                                           LocalDateTime appointmentTime,
                                           String notes) {}

    public record UpdateAppointmentRequest(LocalDateTime appointmentTime,
                                           String status,
                                           String notes) {}

    // ------------------- CREATE -------------------
    @PostMapping
    public ResponseEntity<?> create(@RequestBody CreateAppointmentRequest r) {
        var patient = patientRepo.findById(r.patientId()).orElse(null);
        var provider = providerRepo.findById(r.providerId()).orElse(null);

        if (patient == null || provider == null) {
            return ResponseEntity.badRequest().body("Invalid patient or provider");
        }

        // prevent exact clash for same provider & time
        if (repo.existsByProviderAndAppointmentTime(provider, r.appointmentTime())) {
            return ResponseEntity.badRequest().body("Time slot already taken");
        }

        Appointment a = new Appointment();
        a.setPatient(patient);
        a.setProvider(provider);
        a.setAppointmentTime(r.appointmentTime());
        a.setNotes(r.notes());
        a.setStatus(AppointmentStatus.PENDING);

        return ResponseEntity.ok(repo.save(a));
    }

    // ------------------- GET ALL -------------------
    @GetMapping
    public List<Appointment> getAll() {
        return repo.findAll();
    }

    // ------------------- GET BY ID -------------------
    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id) {
        return repo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ------------------- UPDATE -------------------
    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id,
                                    @RequestBody UpdateAppointmentRequest r) {
        return repo.findById(id).map(a -> {
            if (r.appointmentTime() != null) a.setAppointmentTime(r.appointmentTime());
            if (r.notes() != null) a.setNotes(r.notes());

            if (r.status() != null) {
                try {
                    a.setStatus(AppointmentStatus.valueOf(r.status().toUpperCase()));
                } catch (IllegalArgumentException e) {
                    return ResponseEntity.badRequest().body("Invalid status");
                }
            }

            return ResponseEntity.ok(repo.save(a));
        }).orElse(ResponseEntity.notFound().build());
    }

    // ------------------- DELETE -------------------
    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        return repo.findById(id).map(a -> {
            repo.delete(a);
            return ResponseEntity.ok().build();
        }).orElse(ResponseEntity.notFound().build());
    }
}
