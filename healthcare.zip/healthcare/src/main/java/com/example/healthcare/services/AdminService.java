package com.example.healthcare.services;

import com.example.healthcare.entities.Admin;
import com.example.healthcare.exceptions.ResourceNotFoundException;
import com.example.healthcare.repositories.AdminRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminService {
    private final AdminRepository adminRepo;

    public AdminService(AdminRepository adminRepo) {
        this.adminRepo = adminRepo;
    }

    public List<Admin> getAllAdmins() {
        return adminRepo.findAll();
    }

    public Admin getAdminById(Long id) {
        return adminRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Admin not found with ID: " + id));
    }

    public Admin createAdmin(Admin admin) {
        adminRepo.findByEmail(admin.getEmail())
                .ifPresent(a -> { throw new IllegalArgumentException("Email already registered!"); });
        return adminRepo.save(admin);
    }

    public Admin updateAdmin(Long id, Admin updatedAdmin) {
        Admin admin = getAdminById(id);
        admin.setName(updatedAdmin.getName());
        admin.setEmail(updatedAdmin.getEmail());
        admin.setPhone(updatedAdmin.getPhone());
        admin.setPassword(updatedAdmin.getPassword());
        return adminRepo.save(admin);
    }

    public void deleteAdmin(Long id) {
        Admin admin = getAdminById(id);
        adminRepo.delete(admin);
    }
}
