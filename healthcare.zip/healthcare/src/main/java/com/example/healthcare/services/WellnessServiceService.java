package com.example.healthcare.services;

import com.example.healthcare.entities.WellnessService;
import com.example.healthcare.repositories.WellnessServiceRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WellnessServiceService {
    private final WellnessServiceRepository repo;

    public WellnessServiceService(WellnessServiceRepository repo) {
        this.repo = repo;
    }

    public List<WellnessService> getAllServices() {
        return repo.findAll();
    }

    public WellnessService getServiceById(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Service not found with id: " + id));
    }

    public WellnessService createService(WellnessService service) {
        return repo.save(service);
    }

    public WellnessService updateService(Long id, WellnessService serviceDetails) {
        WellnessService service = getServiceById(id);
        service.setName(serviceDetails.getName());
        service.setDescription(serviceDetails.getDescription());
        service.setDuration(serviceDetails.getDuration());
        service.setFee(serviceDetails.getFee());
        return repo.save(service);
    }

    public void deleteService(Long id) {
        repo.deleteById(id);
    }
}
