// src/main/java/com/example/healthcare/dto/PaymentDTO.java
package com.example.healthcare.dto;

import com.example.healthcare.entities.PaymentStatus;
import java.time.LocalDateTime;

public record PaymentDTO(
        Long id, Long patientId, Long appointmentId, Long serviceId,
        PaymentStatus paymentStatus, LocalDateTime paymentDate, String transactionId) {}
