// File: JwtResponse.java
package com.example.healthcare.auth;

public class JwtResponse {
    private String token;
    private String role;

    public JwtResponse(String token, String role) {
        this.token = token;
        this.role = role;
    }

    // getters
    public String getToken() { return token; }
    public String getRole() { return role; }
}
