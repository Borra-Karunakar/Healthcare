// src/main/java/com/example/healthcare/dto/EnrollmentDTO.java
package com.example.healthcare.dto;

import java.time.LocalDate;

public record EnrollmentDTO(
        Long id, Long patientId, Long serviceId,
        LocalDate startDate, LocalDate endDate, Integer progress) {}
