// src/main/java/com/example/healthcare/config/SecurityConfig.java
package com.example.healthcare.config;

import com.example.healthcare.security.JwtAuthFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig {

    private final JwtAuthFilter jwtAuthFilter;

    public SecurityConfig(JwtAuthFilter jwtAuthFilter) {
        this.jwtAuthFilter = jwtAuthFilter;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .cors(cors -> {}) // allow cross-origin if needed
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)) // stateless JWT
            .authorizeHttpRequests(auth -> auth
                // Public routes
            	.requestMatchers(
            		"/v3/api-docs/**",
            	    "/swagger-ui/**",
            	    "/swagger-ui.html"
            	).permitAll()
                
            	.requestMatchers("/api/auth/**").permitAll()

                // Admin-only routes
                .requestMatchers("/api/admin/**").hasRole("ADMIN")

                // Role-based restrictions
                .requestMatchers("/api/auth/**", "/swagger-ui/**", "/v3/api-docs/**").permitAll()
                .requestMatchers("/api/services/**").authenticated()
                .requestMatchers("/api/appointments/**").hasAnyRole("PATIENT", "PROVIDER", "ADMIN")
                .requestMatchers("/api/enrollments/**").hasAnyRole("PATIENT", "ADMIN")
                .requestMatchers("/api/payments/**").hasAnyRole("PATIENT", "ADMIN")
                .requestMatchers("/api/providers/**").hasAnyRole("PROVIDER", "ADMIN", "PATIENT")
                .requestMatchers("/api/patients/**").hasAnyRole("PATIENT", "ADMIN")

                // Everything else
                .anyRequest().authenticated()
            )
            // Add JWT filter
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
}
