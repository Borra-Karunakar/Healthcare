// src/main/java/com/example/healthcare/repositories/AppointmentRepository.java
package com.example.healthcare.repositories;

import com.example.healthcare.entities.Appointment;
import com.example.healthcare.entities.Patient;
import com.example.healthcare.entities.Provider;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    List<Appointment> findByPatientId(Long patientId);
    List<Appointment> findByProviderId(Long providerId);
    boolean existsByProviderAndAppointmentTime(Provider provider, LocalDateTime at);
}
