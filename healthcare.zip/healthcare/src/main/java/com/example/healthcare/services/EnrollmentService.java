// src/main/java/com/example/healthcare/services/EnrollmentService.java
package com.example.healthcare.services;

import com.example.healthcare.dto.EnrollmentDTO;
import com.example.healthcare.entities.Enrollment;
import com.example.healthcare.entities.Patient;
import com.example.healthcare.entities.WellnessService;
import com.example.healthcare.exceptions.ResourceNotFoundException;
import com.example.healthcare.repositories.EnrollmentRepository;
import com.example.healthcare.repositories.PatientRepository;
import com.example.healthcare.repositories.WellnessServiceRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EnrollmentService {
    private final EnrollmentRepository repo;
    private final PatientRepository patientRepo;
    private final WellnessServiceRepository serviceRepo;

    public EnrollmentService(EnrollmentRepository r, PatientRepository pr, WellnessServiceRepository sr) {
        this.repo = r; this.patientRepo = pr; this.serviceRepo = sr;
    }

    private EnrollmentDTO toDTO(Enrollment e){
        return new EnrollmentDTO(
                e.getId(), e.getPatient().getId(), e.getService().getId(),
                e.getStartDate(), e.getEndDate(), e.getProgress()
        );
    }

    public EnrollmentDTO create(EnrollmentDTO dto){
        Patient p = patientRepo.findById(dto.patientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found"));
        WellnessService s = serviceRepo.findById(dto.serviceId())
                .orElseThrow(() -> new ResourceNotFoundException("Service not found"));
        Enrollment e = new Enrollment();
        e.setPatient(p); e.setService(s);
        e.setStartDate(dto.startDate()); e.setEndDate(dto.endDate());
        e.setProgress(dto.progress() == null ? 0 : dto.progress());
        return toDTO(repo.save(e));
    }

    public List<EnrollmentDTO> byPatient(Long patientId){
        return repo.findByPatientId(patientId).stream().map(this::toDTO).toList();
    }

    public List<EnrollmentDTO> all(){
        return repo.findAll().stream().map(this::toDTO).toList();
    }

    public EnrollmentDTO updateProgress(Long id, Integer progress){
        Enrollment e = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found"));
        e.setProgress(progress);
        return toDTO(repo.save(e));
    }

    public void delete(Long id){ repo.deleteById(id); }
}
