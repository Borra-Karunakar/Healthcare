// src/main/java/com/example/healthcare/controllers/PaymentController.java
package com.example.healthcare.controllers;

import com.example.healthcare.dto.PaymentDTO;
import com.example.healthcare.entities.*;
import com.example.healthcare.exceptions.ResourceNotFoundException;
import com.example.healthcare.repositories.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "http://localhost:3000")
public class PaymentController {
    private final PaymentRepository repo;
    private final PatientRepository patientRepo;
    private final AppointmentRepository apptRepo;
    private final WellnessServiceRepository serviceRepo;

    public PaymentController(PaymentRepository r, PatientRepository pr, AppointmentRepository ar, WellnessServiceRepository sr){
        this.repo = r; this.patientRepo = pr; this.apptRepo = ar; this.serviceRepo = sr;
    }

    private PaymentDTO toDTO(Payment p){
        return new PaymentDTO(
                p.getId(),
                p.getPatient().getId(),
                p.getAppointment() == null ? null : p.getAppointment().getId(),
                p.getService() == null ? null : p.getService().getId(),
                p.getPaymentStatus(),
                p.getPaymentDate(),
                p.getTransactionId()
        );
    }

    @PostMapping
    public ResponseEntity<PaymentDTO> pay(@RequestBody PaymentDTO dto){
        Patient patient = patientRepo.findById(dto.patientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found"));

        Payment p = new Payment();
        p.setPatient(patient);

        if (dto.appointmentId() != null) {
            Appointment a = apptRepo.findById(dto.appointmentId())
                    .orElseThrow(() -> new ResourceNotFoundException("Appointment not found"));
            p.setAppointment(a);
        }
        if (dto.serviceId() != null) {
            WellnessService s = serviceRepo.findById(dto.serviceId())
                    .orElseThrow(() -> new ResourceNotFoundException("Service not found"));
            p.setService(s);
        }
        p.setPaymentStatus(dto.paymentStatus() == null ? PaymentStatus.SUCCESS : dto.paymentStatus());
        p.setTransactionId(dto.transactionId());

        return ResponseEntity.ok(toDTO(repo.save(p)));
    }

    @GetMapping("/patient/{patientId}")
    public ResponseEntity<List<PaymentDTO>> byPatient(@PathVariable Long patientId){
        return ResponseEntity.ok(repo.findByPatientId(patientId).stream().map(this::toDTO).toList());
    }

    @GetMapping
    public ResponseEntity<List<PaymentDTO>> all(){
        return ResponseEntity.ok(repo.findAll().stream().map(this::toDTO).toList());
    }
}
