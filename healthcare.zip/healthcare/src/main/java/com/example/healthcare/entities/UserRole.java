package com.example.healthcare.entities;

public enum UserRole {
    ADMIN,
    PATIENT,
    PROVIDER
}
